package com.refactoring.ch01;

public record Play(
        String name,
        String type
) {
}
