package com.refactoring.ch01;

import java.text.NumberFormat;
import java.util.Locale;
import java.util.Map;


public class Statement {

    public StatementVo statement(Invoice invoice, Map<String, Play> plays) {
        return new StatementVo(invoice, plays);

    }

    public static String toString(StatementVo statementVo) {
        final NumberFormat format = NumberFormat.getCurrencyInstance(Locale.KOREA);

        var result = new StringBuilder("청구 내역 (고객명: " + statementVo.Customer() + ")\n");

        statementVo.EnrichPerformances().stream()
                .map(performance -> String.format(
                        "  %s: %s (%d석)\n",
                        performance.play().name(),
                        format.format(performance.amount()),
                        performance.audience()
                ))
                .forEach(result::append);

        result.append(String.format("총액: %s\n", format.format(statementVo.TotalAmount())));
        result.append(String.format("적립 포인트: %d점\n", statementVo.TotalVolumeCredits()));

        return result.toString();
    }


}
