package com.refactoring.ch01.calculator;

import com.refactoring.ch01.Performance;

public class PerformanceCalculator4Comedy implements PerformanceCalculator {
    @Override
    public int getVolumeCredits(Performance perf) {
        int result = getDefaultVolumnCredits(perf);

        // 희극 관객 5명마다 추가 포인트를 제공한다.
        result += Math.floor(perf.audience() / 5);

        return result;
    }

    @Override
    public int getAmount(Performance perf) {
        int result = 30000;

        if (perf.audience() > 20) {
            result += 10000 + 500 * (perf.audience() - 20);
        }

        result += 300 * perf.audience();

        return result;
    }
}
