package com.refactoring.ch01.calculator;

import com.refactoring.ch01.Performance;

public class PerformanceCalculator4Tragedy implements PerformanceCalculator {
    @Override
    public int getVolumeCredits(Performance perf) {
        // 포인트를 적립한다.
        return getDefaultVolumnCredits(perf);
    }

    @Override
    public int getAmount(Performance perf) {
        int result = 40000;

        if (perf.audience() > 30) {
            result += 1000 * (perf.audience() - 30);
        }

        return result;
    }
}
