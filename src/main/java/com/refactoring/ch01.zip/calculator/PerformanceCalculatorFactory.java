package com.refactoring.ch01.calculator;

import com.refactoring.ch01.Play;

public class PerformanceCalculatorFactory {
    public static PerformanceCalculator getPerformanceCalculator(Play play) {
        return switch(play.type()) {
            case "tragedy" -> new PerformanceCalculator4Tragedy();
            case "comedy" -> new PerformanceCalculator4Comedy();
            default -> throw new IllegalArgumentException("알 수 없는 장르: " + play.type());
        };
    }
}
