package com.refactoring.ch01.calculator;

import com.refactoring.ch01.Performance;

public interface PerformanceCalculator {
    int getVolumeCredits(Performance perf);
    int getAmount(Performance perf);


    default int getDefaultVolumnCredits(Performance perf) {
        return Math.max(perf.audience() - 30, 0);
    }
}