package com.refactoring.ch01;

import com.refactoring.ch01.calculator.PerformanceCalculator;
import com.refactoring.ch01.calculator.PerformanceCalculatorFactory;

import java.util.Map;

public record EnrichPerformance(
        Play play,
        int audience,
        int amount,
        int volumeCredits
) {
    public static EnrichPerformance of(final Performance aPerformance, final Map<String, Play> plays) {
        Play play = plays.get(aPerformance.playID());

        PerformanceCalculator calculator = PerformanceCalculatorFactory.getPerformanceCalculator(play);


        return new EnrichPerformance(
                play,
                aPerformance.audience(),
                calculator.getAmount(aPerformance),
                calculator.getVolumeCredits(aPerformance)
        );
    }
}
