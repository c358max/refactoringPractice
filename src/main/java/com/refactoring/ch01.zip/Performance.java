package com.refactoring.ch01;

public record Performance(
        String playID,
        int audience
) {
}
