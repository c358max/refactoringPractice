package com.refactoring.ch01;

import java.util.List;
import java.util.Map;

public class StatementVo {
    private List<EnrichPerformance> enrichPerformances;
    private String customer;

    public StatementVo(Invoice invoice, Map<String, Play> plays) {
        this.customer = invoice.customer();

        List<Performance> performances = invoice.performances();


        this.enrichPerformances = performances.stream()
                .map(performance -> EnrichPerformance.of(performance, plays))
                .toList();
    }

    public String Customer() {
        return customer;
    }

    public List<EnrichPerformance> EnrichPerformances() {
        return enrichPerformances;
    }

    public int TotalAmount() {
        return enrichPerformances.stream()
                .mapToInt(EnrichPerformance::amount)
                .sum();
    }

    public int TotalVolumeCredits() {
        return enrichPerformances.stream()
                .mapToInt(EnrichPerformance::volumeCredits)
                .sum();
    }

}
